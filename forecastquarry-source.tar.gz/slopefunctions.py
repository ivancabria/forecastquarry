from math import *
import numpy as np
import random
from averages import *
from electricitypricevswindfunctions import *
from rsifunctions import *



def slopefunction(i, price = [], *args):

   # price[i] is the price on day i
   # price[0] is the price on day 0. Today is day 0.
   # price[1] is the price on day 1. Yesterday is day 1.
   previousprice=price[i+1]
   presentprice=price[i]
   slopefunction=presentprice-previousprice
 
   return(slopefunction)



def slopesigma(slopemarket = [], slopewind = [], *args):

   m=len(slopemarket)

   summ = 0.0

   for i in range(0,m):
      diff = slopemarket[i]-slopewind[i]
      summ = summ + diff*diff

   slopesigma = sqrt(summ/m)

   return(slopesigma)



def ssifunction(j, n, slope = [], *args):

   m=len(slope)
   temp = np.zeros(m)
   for i in range(0,m):
      k=i+j-1
      if k<m:
         temp[i]=slope[k]

   ssi=simplemovingaverage(n,temp)

   return(ssi)



def useelectricityforssiarray(nhoursinput, nhpd, model, ssi, useelec):

   p=len(ssi)

   if model=='Alldays':

      for i in range(0,p):
         useelec[i]=1

   elif model=='Randomdays':

      nd=int(nhoursinput/nhpd) # nhoursperday * ndays = nhours
      # Choose nd days randomly between 0 and p-1
      isum=0
      for j in range(0,2*p):
         i=random.randint(0,p-1)
         if useelec[i]==0 and isum<nd:
            isum=isum+1
            useelec[i]=1

   else:

      for i in range(0,p):
         if 0<=i-1:
            useelec[i-1]=useelectricityforssi(model,ssi[i])




def useelectricityforssi(model, ssi):

   if model=='SSI':
      if ssi >= 0.0:
         useelectricityforssi=0
      elif ssi < 0.0:
         useelectricityforssi=1

   elif model=='Alldays':
      useelectricityforssi=1

   else:
      useelectricityforssi=0
 
   return(useelectricityforssi)



def writessi(n, p, ssimarket, ssiwind):

   f = open('ssi.dat', 'w')
   print('#day    i  price   ssi_',n,'  ssi_',n, file=f)
   print('#       -  (€/MWh) market    wind', file=f)
   print('#day    =   p-i    p=',p, file=f)

   for i in range(0,p):
      formatted_pmi = "{:4d}".format(p-i)
      formatted_i = "{:4d}".format(i)
      formatted_price = "{:6.2f}".format(price[i])
      formatted_ssimarket = "{:9.2f}".format(ssimarket[i])
      formatted_ssiwind = "{:9.2f}".format(ssiwind[i])
      print(formatted_pmi, formatted_i, formatted_price, 
      formatted_ssimarket, formatted_ssiwind, file=f)

   f.close()



def windpricearray(m, wind, windprice):

   for i in range(0,m):
      windprice[i]=priceB(wind[i])



def slopearray(m, price, slope):

   for i in range(0,m):
      if i+1<m:
         slope[i]=slopefunction(i,price)



def writeaverageandsigmaslope(slopesigma, averageslopemarket, 
sigmaslopemarket, averageslopewind, sigmaslopewind):

   f = open('slope.dat', 'w')

   formatted_averageslopemarket = "{:.2f}".format(averageslopemarket)
   formatted_sigmaslopemarket = "{:.2f}".format(sigmaslopemarket)

   formatted_averageslopewind = "{:.2f}".format(averageslopewind)
   formatted_sigmaslopewind = "{:.2f}".format(sigmaslopewind)

   formatted_slopesigma = "{:.2f}".format(slopesigma)

   print('Average slope of the market price:                       ',
   formatted_averageslopemarket, file=f)
   print('Standard deviation of the market price:                  ',
   formatted_sigmaslopemarket, file=f)

   print('Average slope of the price based on the wind speed:      ',
   formatted_averageslopewind, file=f)
   print('Standard deviation of the price based on the wind speed: ',
   formatted_sigmaslopewind, file=f)

   print('Sigma of the slopes:                                     ',
   formatted_slopesigma, file=f)

   f.close()



def ssiarray(p, n, slope, ssi):

   for i in range(0,p):
      ssi[i]=ssifunction(i,n,slope)



def writeexpensessi(filename, model, origin, p, expense, nhours, 
averageexpense):

   if nhours > 0:

     #file = open(filename, 'w')
      f = open('expense.dat', 'w')

      f_p = "{:8d}".format(p)
      formatted_expense = "{:9.2f}".format(expense)
      formatted_nhours= "{:9.2f}".format(nhours)
      formatted_averageexpense = "{:9.2f}".format(averageexpense)

      print('model  origin   p  expense(€)  nhours(h)  average', file=f)
      print('-      -        -  -           -          expense', file=f)
      print('-      -        -  -           -          (€/h)', file=f)
      print(model, origin, f_p, formatted_expense, 
      formatted_nhours, formatted_averageexpense, file=f)

      f.close()



def calculateexpense(p, model, price, ssi, nh, expen):

   useelec = []
   useelec = np.zeros(p)
   useelectricityforssiarray(model, ssi, useelec)

   nh=0
   nhpd=nhoursperday(nh, p, model)
   nh=nhours(nhpd, p, useelec)
   expen=expense(nhpd, p, price, useelec)
