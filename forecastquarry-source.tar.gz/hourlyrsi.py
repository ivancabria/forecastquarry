import random
import sys
from rsifunctions import *



frequency='hourly'

# Read the input data
n, model, nhoursinput, originofdata, q, hstop = readinput()



hour = []
price = []
wind = []

readprices(hour, price, wind, frequency, originofdata)



# m is the number of elements of the price array
m=len(price)

# p is the number of the elements of the rsi array
# p should be >= 1
if model=='Usual':
   p=m
else:
   p=m-n

if p<1:
   print('p = ',p,' < 1. p should be >= 1.')
   print('The program hourlyrsi.py stops.')
   sys.exit()



pricefromwind = []
pricefromwind = np.zeros(m)
if originofdata=='market':
   pricefromwindarray(m, wind, originofdata, pricefromwind)



# Calculate the RSI_n's

# To calculate the RSI_n's, the prices of the days 1 to n+1 
# are necessary
# Hence, to calculate RSI_n(1) (day 1), m should be >= n+1
# Hence, to calculate RSI_n(i) (day 2), m should be >= n+2
# Hence, to calculate RSI_n(i) (day i), m should be >= n+i, i>1

# To calculate the RSI_n's, n down and up changes are necessary: 
# down(0), down(1), ... and down(n-1)
# up(0), up(1), ... and up(n-1)

rsi = []
rsi = np.zeros(p+1)
if model=='RSI':
   rsiarray(m, n, p, price, pricefromwind, originofdata, rsi)



nhoursperday=nhoursperday(nhoursinput, p, model, frequency)



# Calculate useelec array
useelec = []
useelec = np.zeros(p)
useelectricityarray(q, frequency, hour, hstop, p, nhoursinput, nhoursperday, 
model, rsi, useelec)

# Calculate nhours
nhours=nhours(nhoursperday, p, useelec)

# Calculate expense. The real price, price[], is used 
# to calculate the expense.
expense=expensev2(p, price, useelec)

# Write the results
if model=='RSI':
   writersi(n, p, hour, price, rsi, useelec, frequency)

writeexpense(hstop, nhours, n, model, originofdata, p, expense)
