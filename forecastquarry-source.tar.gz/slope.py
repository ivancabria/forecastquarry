from electricitypricevswindfunctions import *
from slopefunctions import *
from rsifunctions import *



f = open('windandprice.dat', 'r')
price = []
wind = []

for line in f.readlines():
   fields = line.split(' ')
   wind.append(float(fields[0]))
   price.append(float(fields[1]))

f.close()


# Read n, the period of the SSI
f = open('periodmodelandorigin.dat', 'r')
a = []

for line in f.readlines():
    fields = line.split(' ')
    a.append(fields[0])

f.close()
n=int(a[0])
model=str(a[1]).strip('\n')
origin=str(a[2]).strip('\n')
nhoursinput=int(a[3])



m=len(price)

# Calculate windprice
windprice = []
windprice = np.zeros(m)
windpricearray(m, wind, windprice)

# Calculate slopemarket
slopemarket = []
slopemarket = np.zeros(m)
slopearray(m, price, slopemarket)

# Calculate slopewind
slopewind = []
slopewind = np.zeros(m)
slopearray(m, windprice, slopewind)

# Calculate the averages of the two slopes
averageslopemarket=average(slopemarket)
sigmaslopemarket=sigma(averageslopemarket,slopemarket)

averageslopewind=average(slopewind)
sigmaslopewind=sigma(averageslopewind,slopewind)

# Calculate the sigma of slopewind
slopesigma=slopesigma(slopemarket,slopewind)

# Write the average and sigma slope results
writeaverageandsigmaslope(slopesigma, averageslopemarket, sigmaslopemarket, 
averageslopewind, sigmaslopewind)

# Calculate SSI, Slope Strength Index
p=m-n

ssi = []
ssi = np.zeros(p)
if origin=='market':
   ssiarray(p, n, slopemarket, ssi)
elif origin=='windandmarket':
   ssiarray(p, n, slopewind, ssi)

# Write the SSI results
f = open('ssi.dat', 'w')
print('#day    i  price   ssi_',n, file=f)
print('#       -  (€/MWh)       ', file=f)
print('#day    =   p-i    p=',p, file=f)

for i in range(0,p):
   formatted_pmi = "{:4d}".format(p-i)
   formatted_i = "{:4d}".format(i)
   formatted_price = "{:6.2f}".format(price[i])
   formatted_ssi = "{:9.2f}".format(ssi[i])
   print(formatted_pmi, formatted_i, formatted_price, formatted_ssi, file=f)

f.close()



# Calculate nhpd=nhoursperday
nhpd=nhoursperday(nhoursinput, p, model)

# Calculate useelec and nhpd
useelec = []
useelec = np.zeros(p)
useelectricityforssiarray(nhoursinput, nhpd, model, ssi, useelec)

# Calculate nh, expense and averageexpense
nh=nhours(nhpd, p, useelec)
expense=expense(nhpd, p, price, useelec)
if nh > 0:
   averageexpense=expense/nh
else:
   averageexpense=0.0

# Write the results
filename='expense.dat'
writeexpensessi(filename,model,origin,p,expense,nh,averageexpense)
