from electricitypricevswindfunctions import *



# Open and read the file windaveragepricesigma.dat.
# This file contains three columns of numbers:
# Wind speed in m/s   Average electricity price in euros/MWh
# Sigma in euros/MWh

f = open('windaveragepricesigma.dat', 'r')
wind, averageprice, sigma = [], [], []

for line in f.readlines():
    fields = line.split(' ')
    wind.append(float(fields[0]))
    averageprice.append(float(fields[1]))
    sigma.append(float(fields[2]))

f.close()



# Open and read the file wind.dat. This file contains only a number: the 
# wind speed in m/s at a given time

f = open('wind.dat', 'r')
windinput = []

for line in f.readlines():
    fields = line.split(' ')
    windinput.append(float(fields[0]))

f.close()

#windspeed=windinput[0]



# Calculate the electricity price according to Model A

n = 201

#for n in range(1,202):
#    print(wind[n-1], averageprice[n-1], sigma[n-1])

for n in range(1,202):
    if wind[n-1] == windinput[0]:
        priceA=averageprice[n-1]
        errorA=sigma[n-1]

print('Model A, electricity price = ',round(priceA),'+-',round(errorA),'euros/MWh')



# Calculate the electricity price according to Model B
priceB=priceB(windinput[0])

# The Models A and B have the same error
errorB=errorA

print('Model B, electricity price = ',round(priceB),'+-',round(errorB),'euros/MWh')


