import numpy as np
import random
from averages import *
from electricitypricevswindfunctions import *



def changes(previous,present):
   diff=present-previous

   # up and down should be >= 0.0
   if diff >= 0.0:
      up=diff
      down=0.0
   else:
      up=0.0
      down=-diff

   return (down,up)



def rsifunction(j, n, price = [], *args):

   # Future improvement: The calculation of the rsi(j)'s 
   # with j>1, can be optimized by two different ways:
   # 1. Taking into account that rsi(j) = 
   # rsi(j-1) + somea - someb
   # 2. Calculating the downs and ups necessary to 
   # calculate all the rsi(j)'s

   # To calculate RSI_n, the prices of the days 1 to n+1
   # are necessary
   # Hence, to calculate RSI_n(1) (day 1), 
   # m should be >= n+1
   # Hence, to calculate RSI_n(i) (day 2), 
   # m should be >= n+2
   # Hence, to calculate RSI_n(i) (day i), 
   # m should be >= n+i, i>1

   # To calculate RSI_n, n down and up changes are 
   # necessary: down(0)-down(n-1) and up(0)-up(n-1)

   # Calculate the dimension of the price array
   m=len(price)

   # Initialize the down and up arrays
   down = np.zeros(m)
   up = np.zeros(m)

   # Calculation of the down and up arrays

   # price[i] is the price on day i
   # price[1] is the price on day 1, Today is day 1.

   # Future improvement: This for loop could be optimized, 
   # by using for i in range(0,n+1):
   for i in range(0,m):
      if i+1 < m:
         previousprice=price[i+1]
         presentprice=price[i]
         d,u=changes(previousprice,presentprice)
         down[i]=d
         up[i]=u
        #print('i d u = ',i,d,u) # Print sentence for test purposes

   tempdown = np.zeros(m)
   tempup = np.zeros(m)
   for i in range(0,m):
      k=i+j-1
      if k<m:
         tempdown[i]=down[k]
         tempup[i]=up[k]

   # smadown and smaup should be >= 0.0
   # smadown and smaup should be >= 0.0
   smadown=simplemovingaverage(n,tempdown)
   smaup=simplemovingaverage(n,tempup)

   if smadown > 0.0:
      rs = smaup/smadown
      rsifunction = 100.0 - 100.0/(1.0 + rs)
   else:
      rsifunction = 100.0
 
   return(rsifunction)



def useelectricity(model, rsi1, rsi2, rsi3):

   if model=='RSI':
      if rsi1 >= 70.0:
         useelectricity=0
      elif rsi1 <= 30.0:
         useelectricity=1
      else:
         if rsi3 >= rsi2 >= rsi1:
            useelectricity=1
         else:
            useelectricity=0

   elif model=='Alldays':
      useelectricity=1

   else:
      useelectricity=0
 
   return(useelectricity)



def expense(nhoursperday, p, price = [], useelectricity = [], *args):

   expense=0.0
  #print('p=',p)
   for i in range(0,p):
     #print(i,price[i],useelectricity[i])
      expense = expense + nhoursperday*useelectricity[i]*price[i]

   return(expense)



def expensev2(p, price = [], useelectricity = [], *args):

   expense=0.0
   for i in range(0,p):
      expense = expense + useelectricity[i]*price[i]

   return(expense)



def nhours(nhoursperday, p, useelectricity = [], *args):

   nhours=0
   for i in range(0,p):
      nhours = nhours + nhoursperday*useelectricity[i]

   return(nhours)



def nhoursperday(nhours, p, model, frequency):

   if frequency=='daily':
      if model=='RSI':
         nhoursperday=5
      elif model=='Alldays':
         nhoursperday=nhours/p
      else:
         nhoursperday=5
   elif frequency=='hourly':
      nhoursperday=1
   else:
      nhoursperday=1

   return(nhoursperday)



def useelectricityarray(q, frequency, hour, hstop, p, nhoursinput, nhoursperday, 
model, rsi, useelec):

   if frequency=='daily':

      if model=='RSI':
         for i in range(0,p):
            if i+2<=p and 0<=i-1:
               useelec[i-1]=useelectricity(model,rsi[i],rsi[i+1],rsi[i+2])

      elif model=='Alldays':
         for i in range(0,p):
            useelec[i]=1

      elif model=='Randomdays':
         nd=int(nhoursinput/nhoursperday) # nhoursperday * ndays = nhours
         # Choose nd days randomly between 0 and p-1
         isum=0
         for j in range(0,2*p):
            i=random.randint(0,p-1)
            if useelec[i]==0 and isum<nd:
               isum=isum+1
               useelec[i]=1

      elif model=='Usual':
         for i in range(0,p):
            useelec[i]=1
         useelec[hstop]=0

   elif frequency=='hourly':

      # The working hours are: 8, 9, ..., 15 and 16
      # Hence, initially useelec=1 for those hours

      for i in range(0,p):
         if 8<=hour[i] and hour[i]<=16:
            useelec[i]=1

      if model=='RSI':

         # Find ipivot
         for i in range(p,0,-1):
            if hour[i]==8:
               ipivot=i
               break

         # Calculate the number of days
         ndays=0
         for i in range(0,p):
            if hour[i]==8:
               ndays=ndays+1

         for d in range(0,ndays+1):
            i = ipivot - (d-1)*24
            jmax=min(i,p)        
            for j in range(i,i-9,-1):
               if 0 <= j and j <= p:
                  if rsi[j] > rsi[jmax]:
                     jmax=j
            useelec[jmax-q]=0
   
      elif model=='Usual':

         for i in range(0,p):
            if hour[i]==hstop:
               useelec[i]=0

      # If useelec[i] corresponds to an hour outside 
      # the working hours, then useelec[i]=0
      # The working hours are: 8, 9, ..., 15 and 16

      for i in range(0,p):
         if hour[i]<8 or hour[i]>16:
            useelec[i]=0



def rsiarray(m, n, p, price, pricefromwind, originofdata, rsi):

   if originofdata=='market': # data come from market

      for i in range(0,p):
         if m >= n+i:
            rsi[i]=rsifunction(i,n,price)

   else: # data come from wind and market

      for i in range(0,p):
         if m >= n+i:
            rsi[i]=rsifunction(i,n,pricefromwind)



def writeexpense(hstop, nhours, n, model, originofdata, p, expense):

   if nhours > 0:

      averageexpense=expense/nhours
      f = open('expense.dat', 'w')

      print('origin model          n      p   expense   nhours  average', file=f)
      print('ofdata                             (€)    (hours)  expense', file=f)
      print('                                                    (€/h)',  file=f)

      if model=='Usual':

         foriginofdata = "{:7s}".format(originofdata)
         fmodel = "{:5s}".format(model)
         if hstop<10:
            fhstop = "{:1d}".format(hstop)
            fn = "{:10d}".format(n)
         else:
            fhstop = "{:2d}".format(hstop)
            fn = "{:9d}".format(n)

         fp = "{:7d}".format(p)
         fexpense = "{:10.2f}".format(expense)
         fnhours= "{:9d}".format(int(nhours))
         faverageexpense = "{:9.3f}".format(averageexpense)
         print(foriginofdata, fmodel, fhstop, fn, fp, fexpense, 
         fnhours, faverageexpense, file=f, sep='')

      else:

         foriginofdata = "{:6s}".format(originofdata)
         fmodel = "{:10s}".format(model)
         fn = "{:5d}".format(n)
         fp = "{:6d}".format(p)
         fexpense = "{:9.2f}".format(expense)
         fnhours= "{:8d}".format(int(nhours))
         faverageexpense = "{:8.3f}".format(averageexpense)
         print(foriginofdata, fmodel, fn, fp, fexpense, 
         fnhours, faverageexpense, file=f)

      f.close()



def writersi(n, p, hour, price, rsi, useelec, frequency):

   f = open('rsi.dat', 'w')

   if frequency=='daily':

      print('#day  i  price        rsi_',n, file=f)
      print('#-    -  (€/MWh)  -', file=f)
      print('#p =',p, 'day = p - i', file=f)
      for i in range(0,p):
         formatted_price = "{:.2f}".format(price[i])
         formatted_rsi = "{:.2f}".format(rsi[i])
         print(p-i, i, formatted_price, formatted_rsi, file=f)

   elif frequency=='hourly':

      print('#p-i  hour    price  hourly   use', file=f)
      print('#-    -     (€/MWh)  rsi_',n,' elec', file=f)
      print('#p =',p, file=f)
      for i in range(0,p):
         formatted_pmi = "{:6d}".format(p-i)
         formatted_hour = "{:3d}".format(int(hour[i]))
         formatted_price = "{:8.2f}".format(price[i])
         formatted_rsi = "{:7.2f}".format(rsi[i])
         formatted_useelec = "{:6.2f}".format(useelec[i])
         print(formatted_pmi, formatted_hour, formatted_price, 
         formatted_rsi, formatted_useelec, file=f)

   f.close()



def pricefromwindarray(m, wind, originofdata, pricefromwind):

   if originofdata=='windandmarket': # data come from wind and market

      # Calculate pricefromwind
      for i in range(0,m):
         pricefromwind[i]=priceB(wind[i])



def readprices(hour, price, wind, frequency, originofdata):

   if frequency=='hourly':

      if originofdata=='market': # data come from market

         # Open and read the file prices.dat
         # This file contains two columns of numbers: 
         # First column: The hour i of a day. i runs from 0 to 23
         # The electricity price in €/MWh at the hour i of a day

         # The prices in file prices.dat should be sorted out as 
         # follows:
         # Line x contains the price on hour x. x runs from 1 to N*24
         # Now is hour 1
         # One hour ago is hour 2

         f = open('prices.dat', 'r')

         for line in f.readlines():
            fields = line.split(' ')
            hour.append(float(fields[1]))
            price.append(float(fields[2]))

         f.close()

      else: # data come from wind and market
   
         # Open and read the file windspeed.dat
         # This file contains one column of numbers: The 
         # wind speed in m/s at 12:00 in the noon 
         # in the last m days

         f = open('windandprice.dat', 'r')

         for line in f.readlines():
            fields = line.split(' ')
            hour.append(float(fields[0]))
            wind.append(float(fields[1]))
            price.append(float(fields[2]))

         f.close()

   elif frequency=='daily':

      if originofdata=='market': # data come from market

         # Open and read the file prices.dat
         # This file contains one column of numbers: The 
         # electricity price in €/MWh at 12:00 in the noon 
         # in the last m days

         # The prices in file prices.dat should be sorted out as 
         # follows:
         # Line x contains the price on day x
         # Today is day 1
         # Yesterday is day 2

         f = open('prices.dat', 'r')

         for line in f.readlines():
            fields = line.split(' ')
            price.append(float(fields[0]))

         f.close()

      else: # data come from wind and market
  
         # Open and read the file windspeed.dat
         # This file contains one column of numbers: The 
         # wind speed in m/s at 12:00 in the noon 
         # in the last m days

         f = open('windandprice.dat', 'r')

         for line in f.readlines():
            fields = line.split(' ')
            wind.append(float(fields[0]))
            price.append(float(fields[1]))

         f.close()



def readinput():

   # Open and read the file rsiinput.dat. This file 
   # contains several variables: the period n of the RSI 
   # index, the type of model, the number of hours, 
   # the origin of the data and the number of days ahead of the 
   # predictions, q.

   a = []

   f = open('rsiinput.dat', 'r')

   for line in f.readlines():
      fields = line.split(' ')
      a.append(fields[0])

   f.close()

   n=int(a[0])
   model=str(a[1]).strip('\n')
   nhoursinput=int(a[2])
   originofdata=str(a[3]).strip('\n')
   q=int(a[4])
   hstop=int(a[5])

   return(n, model, nhoursinput, originofdata, q, hstop)
