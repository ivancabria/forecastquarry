def priceB(windspeed):

   # windspeed: Wind speed in m/s

   # Open and read the file windfitcoefficients.dat
   f = open('windfitcoefficients.dat', 'r')
   coeff = []

   for line in f.readlines():
      fields = line.split(' ')
      coeff.append(float(fields[0]))

   f.close()

   priceB=coeff[0] + coeff[1]*windspeed + coeff[2]*windspeed*windspeed

   return(priceB)
